package cz.czechitas.knihy;

import java.util.*;
import javax.swing.*;

public class StatickyZdrojKnih implements ZdrojDat {

    private List<Kniha> knihy;
    private Pomocnik pomocnik = new Pomocnik();

    public StatickyZdrojKnih() {
        knihy = new ArrayList<>();
        nactiKnihu("The Decameron", "Giovanni Boccaccio", 1351, 1024, "Italian", "images/the-decameron.jpg");
        nactiKnihu("Don Quijote De La Mancha", "Miguel de Cervantes", 1610, 1056, "Spanish", "images/don-quijote-de-la-mancha.jpg");
        nactiKnihu("The Canterbury Tales", "Geoffrey Chaucer", 1450, 544, "English", "images/the-canterbury-tales.jpg");
        nactiKnihu("Jacques the Fatalist", "Denis Diderot", 1796, 596, "French", "images/jacques-the-fatalist.jpg");
    }

    private void nactiKnihu(String titul, String autor, Integer rokVydani, Integer pocetStran, String jazyk, String ikonka) {
        ImageIcon ikona = pomocnik.nactiIkonku(ikonka);
        Kniha nactenaKniha = new Kniha(titul, autor, rokVydani, pocetStran, jazyk);
        nactenaKniha.setObrazek(ikona);
        knihy.add(nactenaKniha);
    }

    @Override
    public List<Kniha> getKnihy() {
        return knihy;
    }
}
