package cz.czechitas.knihy;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    Kniha kniha;
    KnihovniSluzba knihovniSluzba;
    ZdrojDat zdrojDat;

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JMenuBar menuBar1;
    JMenu menuSoubor;
    JMenuItem menuOtevrit;
    JMenuItem menuUlozit;
    JButton btnNahodnaKnizka;
    JLabel labHledejKnihuPodleNazvuTitulek;
    JTextField txtHledejKnihuPodleNazvu;
    JButton btnHledej;
    JLabel labPodrobnostiOKnizce;
    JLabel labIkona;
    JLabel labTitulTitulek;
    JLabel labTitul;
    JLabel labAutorTitulek;
    JLabel labAutor;
    JLabel labRokVydaniTitulek;
    JLabel labRokVydani;
    JLabel labPocetStranTitulek;
    JLabel labPocetStran;
    JLabel labJazykTitulek;
    JLabel labJazyk;
    JLabel labHodnoceniTitulekSRoletkou;
    JComboBox<String> boxHodnoceni;
    JLabel labHodnoceniTitulek;
    JLabel labHodnoceni;
    JLabel labPocetKnihTitulek;
    JLabel labPocetKnih;
    JLabel labPocetJazykuTitulek;
    JLabel labPocetJazyku;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;

    public HlavniOkno() {
        initComponents();

        nastavKnihovniSluzbu(new StatickyZdrojKnih());
        knihovniSluzba.getNahodnouKnihu();
    }

    private void priStiskuBtnNahodnaKnizka(ActionEvent e) {
        kniha = knihovniSluzba.getNahodnouKnihu();
        nastavAktualniKnihu();
    }

    private void nastavAktualniKnihu() {
        labAutor.setText(kniha.getAutor());
        labTitul.setText(kniha.getTitul());
        labJazyk.setText(kniha.getJazyk());
        labRokVydani.setText(String.valueOf(kniha.getRokVydani()));
        labPocetStran.setText(String.valueOf(kniha.getPocetStran()));
        labIkona.setIcon(kniha.getObrazek());
        boxHodnoceni.setSelectedItem(kniha.getHodnoceni());
        labHodnoceni.setText(String.valueOf(kniha.getHodnoceni()));
    }

    private void menuOtevritSoubor(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        int vysledek = fileChooser.showOpenDialog(this);
        if (vysledek == JFileChooser.APPROVE_OPTION) {
            File soubor = fileChooser.getSelectedFile();
            nastavKnihovniSluzbu(new SouborovyZdrojDat(soubor));
            nastavAktualniKnihu();
        }
    }

    private void nastavKnihovniSluzbu(ZdrojDat zdroj) {
        this.zdrojDat = zdroj;
        this.knihovniSluzba = new KnihovniSluzba(zdroj);
        nastavPocetKnih();
        nastavPocetJazyku();
    }

    private void nastavPocetJazyku() {
        int pocetJazyku = knihovniSluzba.getPocetJazyku();
        labPocetJazyku.setText(String.valueOf(pocetJazyku));
    }

    private void nastavPocetKnih() {
        int pocetKnih = knihovniSluzba.getPocetKnih();
        labPocetKnih.setText(String.valueOf(pocetKnih));
    }

    private void menuUlozitSoubor(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        int vysledek = fileChooser.showSaveDialog(this);
        if (vysledek == JFileChooser.APPROVE_OPTION) {
            File soubor = fileChooser.getSelectedFile();
            knihovniSluzba.ulozKnihy(soubor);
        }
    }

    private void vyberHodnoceniVRoletce(ActionEvent e) {
        kniha.setHodnoceni(boxHodnoceni.getItemAt(boxHodnoceni.getSelectedIndex()));
        nastavAktualniKnihu();
    }

    private void priStiskuBtnHledej(ActionEvent e) {
        kniha = knihovniSluzba.VyhledatTitul(txtHledejKnihuPodleNazvu.getText());
        nastavAktualniKnihu();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        menuBar1 = new JMenuBar();
        menuSoubor = new JMenu();
        menuOtevrit = new JMenuItem();
        menuUlozit = new JMenuItem();
        btnNahodnaKnizka = new JButton();
        labHledejKnihuPodleNazvuTitulek = new JLabel();
        txtHledejKnihuPodleNazvu = new JTextField();
        btnHledej = new JButton();
        labPodrobnostiOKnizce = new JLabel();
        labIkona = new JLabel();
        labTitulTitulek = new JLabel();
        labTitul = new JLabel();
        labAutorTitulek = new JLabel();
        labAutor = new JLabel();
        labRokVydaniTitulek = new JLabel();
        labRokVydani = new JLabel();
        labPocetStranTitulek = new JLabel();
        labPocetStran = new JLabel();
        labJazykTitulek = new JLabel();
        labJazyk = new JLabel();
        labHodnoceniTitulekSRoletkou = new JLabel();
        boxHodnoceni = new JComboBox<>();
        labHodnoceniTitulek = new JLabel();
        labHodnoceni = new JLabel();
        labPocetKnihTitulek = new JLabel();
        labPocetKnih = new JLabel();
        labPocetJazykuTitulek = new JLabel();
        labPocetJazyku = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("knihy");
        setMinimumSize(new Dimension(700, 700));
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[]" +
            "[fill]" +
            "[fill]" +
            "[fill]",
            // rows
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //======== menuBar1 ========
        {

            //======== menuSoubor ========
            {
                menuSoubor.setText("Soubor");

                //---- menuOtevrit ----
                menuOtevrit.setText("Otev\u0159\u00edt");
                menuOtevrit.addActionListener(e -> menuOtevritSoubor(e));
                menuSoubor.add(menuOtevrit);

                //---- menuUlozit ----
                menuUlozit.setText("Ulo\u017eit");
                menuUlozit.addActionListener(e -> menuUlozitSoubor(e));
                menuSoubor.add(menuUlozit);
            }
            menuBar1.add(menuSoubor);
        }
        setJMenuBar(menuBar1);

        //---- btnNahodnaKnizka ----
        btnNahodnaKnizka.setText("N\u00e1hodn\u00e1 kn\u00ed\u017eka:");
        btnNahodnaKnizka.addActionListener(e -> priStiskuBtnNahodnaKnizka(e));
        contentPane.add(btnNahodnaKnizka, "cell 0 0");

        //---- labHledejKnihuPodleNazvuTitulek ----
        labHledejKnihuPodleNazvuTitulek.setText("Hledej kn\u00ed\u017eku podle n\u00e1zvu:");
        contentPane.add(labHledejKnihuPodleNazvuTitulek, "cell 1 0");

        //---- txtHledejKnihuPodleNazvu ----
        txtHledejKnihuPodleNazvu.setColumns(15);
        contentPane.add(txtHledejKnihuPodleNazvu, "cell 2 0");

        //---- btnHledej ----
        btnHledej.setText("Hledej");
        btnHledej.addActionListener(e -> priStiskuBtnHledej(e));
        contentPane.add(btnHledej, "cell 3 0");

        //---- labPodrobnostiOKnizce ----
        labPodrobnostiOKnizce.setText("Podrobnosti o kn\u00ed\u017ece:");
        contentPane.add(labPodrobnostiOKnizce, "cell 0 1");
        contentPane.add(labIkona, "cell 2 1 2 9");

        //---- labTitulTitulek ----
        labTitulTitulek.setText("Titul:");
        contentPane.add(labTitulTitulek, "cell 0 3");

        //---- labTitul ----
        labTitul.setText("Nastavit");
        contentPane.add(labTitul, "cell 1 3");

        //---- labAutorTitulek ----
        labAutorTitulek.setText("Autor:");
        contentPane.add(labAutorTitulek, "cell 0 4");

        //---- labAutor ----
        labAutor.setText("Nastavit");
        contentPane.add(labAutor, "cell 1 4");

        //---- labRokVydaniTitulek ----
        labRokVydaniTitulek.setText("Rok Vyd\u00e1n\u00ed:");
        contentPane.add(labRokVydaniTitulek, "cell 0 5");

        //---- labRokVydani ----
        labRokVydani.setText("Nastavit");
        contentPane.add(labRokVydani, "cell 1 5");

        //---- labPocetStranTitulek ----
        labPocetStranTitulek.setText("Po\u010det stran:");
        contentPane.add(labPocetStranTitulek, "cell 0 6");

        //---- labPocetStran ----
        labPocetStran.setText("Nastavit");
        contentPane.add(labPocetStran, "cell 1 6");

        //---- labJazykTitulek ----
        labJazykTitulek.setText("Jazyk:");
        contentPane.add(labJazykTitulek, "cell 0 7");

        //---- labJazyk ----
        labJazyk.setText("Nastavit");
        contentPane.add(labJazyk, "cell 1 7");

        //---- labHodnoceniTitulekSRoletkou ----
        labHodnoceniTitulekSRoletkou.setText("Hodnocen\u00ed:");
        contentPane.add(labHodnoceniTitulekSRoletkou, "cell 0 8");

        //---- boxHodnoceni ----
        boxHodnoceni.setBorder(new BevelBorder(BevelBorder.LOWERED));
        boxHodnoceni.setMaximumRowCount(5);
        boxHodnoceni.setToolTipText("12345");
        boxHodnoceni.setModel(new DefaultComboBoxModel<>(new String[] {
            "1",
            "2",
            "3",
            "4",
            "5"
        }));
        boxHodnoceni.addActionListener(e -> vyberHodnoceniVRoletce(e));
        contentPane.add(boxHodnoceni, "cell 1 8,align left center,grow 0 0");

        //---- labHodnoceniTitulek ----
        labHodnoceniTitulek.setText("Jak\u00e9 m\u00e1 hodnocen\u00ed:");
        contentPane.add(labHodnoceniTitulek, "cell 0 9");

        //---- labHodnoceni ----
        labHodnoceni.setText("?");
        contentPane.add(labHodnoceni, "cell 1 9");

        //---- labPocetKnihTitulek ----
        labPocetKnihTitulek.setText("Po\u010det knih:");
        contentPane.add(labPocetKnihTitulek, "cell 0 10");

        //---- labPocetKnih ----
        labPocetKnih.setText("0");
        contentPane.add(labPocetKnih, "cell 1 10,alignx left,growx 0");

        //---- labPocetJazykuTitulek ----
        labPocetJazykuTitulek.setText("Po\u010det jazyk\u016f:");
        contentPane.add(labPocetJazykuTitulek, "cell 2 10");

        //---- labPocetJazyku ----
        labPocetJazyku.setText("0");
        contentPane.add(labPocetJazyku, "cell 3 10,alignx left,growx 0");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
