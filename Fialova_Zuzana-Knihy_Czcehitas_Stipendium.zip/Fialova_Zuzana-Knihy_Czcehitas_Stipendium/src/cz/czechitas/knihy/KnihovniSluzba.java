package cz.czechitas.knihy;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class KnihovniSluzba {
    private ZdrojDat zdroj;

    public KnihovniSluzba(ZdrojDat zdroj) {
        this.zdroj = zdroj;
    }

    public Kniha getNahodnouKnihu() {
        Random random = new Random();
        List<Kniha> vyberKnih = new ArrayList<>();
        int cisloCitatu = random.nextInt(getPocetKnih());
        for (Kniha c : zdroj.getKnihy()) {
            vyberKnih.add(c);
        }
        Kniha nahodnyCitat = vyberKnih.get(cisloCitatu);
        return nahodnyCitat;
    }

    public int getPocetKnih() {
        int pocetKnih = zdroj.getKnihy().size();
        return pocetKnih;
    }

    public int getPocetJazyku() {
        Set<String> jazyk = new HashSet<>();
        for (Kniha kniha : zdroj.getKnihy()) {
            String jakyJazyk;
            jakyJazyk = kniha.getJazyk();
            jazyk.add(jakyJazyk);
        }
        int pocet = jazyk.size();
        return pocet;
    }

    public void ulozKnihy(File soubor) {
        Pomocnik pomocnik = new Pomocnik();
        List<String> knihy = new ArrayList<>();

        for (Kniha kniha : zdroj.getKnihy()) {
            String autor = kniha.getAutor();
            String titul = kniha.getTitul();
            String jazyk = kniha.getJazyk();
            Integer pocetStranInt = kniha.getPocetStran();
            String pocetStran = String.valueOf(pocetStranInt);
            Integer rokVydaniInt = kniha.getRokVydani();
            String rokVydani = String.valueOf(rokVydaniInt);
            ImageIcon ikonaI = kniha.getObrazek();
            String ikona = String.valueOf(ikonaI);

            // OPRAVA: k cemu pridavame jednotlive casti radku samostatne?
            knihy.add(autor);
            knihy.add(titul);
            knihy.add(jazyk);
            knihy.add(String.valueOf(pocetStran));
            knihy.add(String.valueOf(rokVydani));
            knihy.add(String.valueOf(ikona));

            // OPRAVA: Ikonku nelze takto prevest na String (vysldek je neco jako:javax.swing.ImageIcon@4d2b91e9)
            //         je potreba ulozit puvodni cestu k ikonce (tzn je potreba si ji pamatovat)
            String jedenRadek = titul + ";" + autor + ";" + rokVydani + ";" + pocetStran + ";" + jazyk + ";" + ikona;
            knihy.add(jedenRadek);
        }
        pomocnik.zapisRadkyDoSouboru(knihy, soubor);
    }

   public Kniha VyhledatTitul(String hledanaKniha) {
        for (Kniha kniha : zdroj.getKnihy()) {
            if (kniha.getTitul().startsWith(hledanaKniha))
                return kniha;
        }
       Kniha nenalezena = new Kniha("V seznamu se nenachází kniha s tímto názvem.", "");
        return zdroj.getKnihy().get(0);
    }

}
