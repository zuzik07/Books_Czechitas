package cz.czechitas.knihy;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;

public class Pomocnik {

    /**
     * Metoda nacte radky ze souboru na dane ceste
     *
     * @param soubor soubor ktery chceme cist
     * @return Seznam radku nebo prazdny seznam pokud nastala chyba
     */
    public List<String> nactiRadkySouboru(File soubor) { // Tady jsme oproti 8. lekci upravili parametr
        try {
            Path cesta = soubor.toPath();  // Zjistime cestu k souboru
            List<String> radky = Files.readAllLines(cesta);
            return radky;
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    /**
     * Rozdeli radek na jednotlive casti, ktere vrati jako nasledujici seznam
     *
     * 0: titul
     * 1: autor
     * 2: rok vydani
     * 3: pocet stran
     * 4: jazyk
     * 5: obrazek
     *
     * @param radek radek souboru s informacemi o knize
     * @return seznam jednoltivych casti
     */
    public List<String> rozdelRadek(String radek) {
        String[] data = radek.split(";");
        return new ArrayList<>(Arrays.asList(data));
    }

    /**
     * Metoda zapise radky do souboru
     * @param radky seznam jednotlivych radku
     * @param soubor soubor ktery chceme zapisovat
     */
    public void zapisRadkyDoSouboru(List<String> radky, File soubor) { // Tady jsme oproti 8. lekci upravili parametr
        String obsah = String.join(System.lineSeparator(), radky); // Zjistime cestu k souboru
        try {
            Path cesta = soubor.toPath();
            Files.write(cesta, obsah.getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Nacte ikonku
     *
     * @param cestaKSouboru cesta k souboru ikonky
     * @return ikonka
     */
    public ImageIcon nactiIkonku(String cestaKSouboru) {
        try {
            return new ImageIcon(ImageIO.read(getClass().getResourceAsStream(cestaKSouboru)));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



}
