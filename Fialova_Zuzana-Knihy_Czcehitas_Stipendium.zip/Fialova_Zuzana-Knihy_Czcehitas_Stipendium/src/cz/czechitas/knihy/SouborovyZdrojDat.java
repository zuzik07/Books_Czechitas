package cz.czechitas.knihy;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class SouborovyZdrojDat implements ZdrojDat {
    private List<Kniha> knihy;
    private File soubor;

    public SouborovyZdrojDat(File soubor) {
        knihy = nactiKnihyZeSouboru(soubor);
        this.soubor = soubor;
    }

    private List<Kniha> nactiKnihyZeSouboru(File zdroj) {
        List<Kniha> knihy = new ArrayList<>();
        Pomocnik pomocnik = new Pomocnik();
        List<String> radky = pomocnik.nactiRadkySouboru(zdroj);

        for (int i = 0; i < radky.size(); i++) {
            String radek = radky.get(i);
            List<String> rozdelRadeknaCasti = pomocnik.rozdelRadek(radek);

            String titul = rozdelRadeknaCasti.get(0);
            String autor = rozdelRadeknaCasti.get(1);
            String rokVydani = rozdelRadeknaCasti.get(2);
            int rok = Integer.parseInt(rokVydani);
            //prevedTextNaCislo(rok);
            String pocetStranVKnize = rozdelRadeknaCasti.get(3);
            int pocetStran = Integer.parseInt(pocetStranVKnize);
            //prevedTextNaCislo(pocetStran);
            String jazyk = rozdelRadeknaCasti.get(4);
            String obrazek = rozdelRadeknaCasti.get(5);
            ImageIcon ikona = pomocnik.nactiIkonku(obrazek);

            Kniha nactenaKniha = new Kniha(titul, autor, rok, pocetStran, jazyk);
            nactenaKniha.setObrazek(ikona);
            knihy.add(nactenaKniha);
        }
        return knihy;
    }

    public void prevedTextNaCislo(String preved) {
        int cislo = Integer.parseInt(preved);
    }

    @Override
    public List<Kniha> getKnihy() {
        return knihy;
    }
}
