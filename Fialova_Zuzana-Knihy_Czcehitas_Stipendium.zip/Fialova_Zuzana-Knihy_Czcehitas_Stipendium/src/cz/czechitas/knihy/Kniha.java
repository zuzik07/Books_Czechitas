package cz.czechitas.knihy;

import javax.swing.*;

public class Kniha {
    private String titul;
    private String autor;
    private String jazyk;
    private Integer rokVydani;
    private Integer pocetStran;
    private String hodnoceni;
    private ImageIcon obrazek;

    public Kniha(String titul, String autor, int rokVydani, int pocetStran, String jazyk) {
        this.titul = titul;
        this.autor = autor;
        this.jazyk = jazyk;
        this.rokVydani = rokVydani;
        this.pocetStran = pocetStran;
    }

    public Kniha(String titul, String autor) {
        this.titul = titul;
        this.autor = autor;
    }

    public String getTitul() {
        return titul;
    }

    public String getJazyk() {
        return jazyk;
    }

    public String getAutor() {
        return autor;
    }

    public Integer getRokVydani() {
        return rokVydani;
    }

    public Integer getPocetStran() {
        return pocetStran;
    }

    public String getHodnoceni() {
        return hodnoceni;
    }

    public ImageIcon getObrazek() {
        return obrazek;
    }

    public void setObrazek(ImageIcon newValue) {
        obrazek = newValue;
    }

    public void setHodnoceni(String newValue) {
        hodnoceni = newValue;
    }

}
