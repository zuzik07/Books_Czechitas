package cz.czechitas.knihy;

import java.util.*;
import cz.czechitas.knihy.*;

/**
 *  Rozhrani (Interface) predstavuje "obecny typ". Priorvnani z realneho sveta by bylo
 *
 *  Rozhrani nam rika co vsechno musi byt definovano v kazde tride, ktera jej chce implementovat
 *  Tzn. co vsechno musi umet kazdy zdroj dat
 *      vami definovany SoborovyZdrojDat musi definovat metodu getKnihy, ktera vrati seznam citatu
 *
 */
public interface ZdrojDat {
    public List<Kniha> getKnihy();
}
